# Studion

This is the first project of the Frontend Developer course for the Imagine School class of 2020.

## How to work with the repository / Como trabalhar com o repositório

### Clone the project / Clone o projeto

```
git clone http://github.com/brucecantarim/studion.git
```

### Install the project dependencies / Instalar as dependências do projeto

```
cd studion
npm install
```

### Start the project / Iniciar o projeto

```
npm start
```

### Questions? / Perguntas

Send me an email at [bruce@cantarim.com](mailto:bruce@cantarim.com)
